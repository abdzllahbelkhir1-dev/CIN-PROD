import React from 'react';

export enum PageView {
  HOME = 'home',
  PORTFOLIO = 'portfolio',
  SERVICES = 'services',
  CONTACT = 'contact'
}

export interface Project {
  id: number;
  title: string;
  category: string;
  image?: string;
  youtubeId?: string;
  description: string;
}

export interface Service {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  image: string;
}