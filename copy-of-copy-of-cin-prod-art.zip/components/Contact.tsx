import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Instagram, Facebook, Youtube } from 'lucide-react';

const Contact: React.FC = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormState({ ...formState, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setFormState({ name: '', email: '', phone: '', service: '', message: '' });
    }, 1500);
  };

  return (
    <section className="min-h-screen bg-zinc-950 pt-24 pb-12 px-4 relative flex items-center">
      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
        
        {/* Contact Info Side */}
        <div className="flex flex-col justify-center">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            تواصل <br />
            <span className="text-gold">معنا</span>
          </h2>
          <p className="text-zinc-400 text-lg mb-12">
             هل لديك فكرة تريد تحويلها إلى واقع؟ تواصل معنا اليوم لمناقشة تفاصيل مشروعك الفني.
          </p>

          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-zinc-900 flex items-center justify-center rounded text-yellow-500 border border-zinc-800">
                <Phone size={24} />
              </div>
              <div>
                <h4 className="text-white font-semibold">الهاتف</h4>
                <p className="text-zinc-400 dir-ltr text-right">28731899</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-zinc-900 flex items-center justify-center rounded text-yellow-500 border border-zinc-800">
                <Mail size={24} />
              </div>
              <div>
                <h4 className="text-white font-semibold">البريد الإلكتروني</h4>
                <p className="text-zinc-400">abdzllahbelkhir1@gmail.com</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-zinc-900 flex items-center justify-center rounded text-yellow-500 border border-zinc-800">
                <MapPin size={24} />
              </div>
              <div>
                <h4 className="text-white font-semibold">الموقع</h4>
                <p className="text-zinc-400">منزل عبد الرحمان</p>
              </div>
            </div>
          </div>

          <div className="mt-12">
            <h4 className="text-white font-bold mb-4">تابعنا على السوشيال ميديا</h4>
            <div className="flex gap-4">
              <a href="https://www.facebook.com/Baayyggaa" target="_blank" rel="noreferrer" className="w-10 h-10 rounded bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-yellow-500 hover:border-yellow-500 transition-all">
                <Facebook size={20} />
              </a>
              <a href="https://www.instagram.com/bayyygggaaa/" target="_blank" rel="noreferrer" className="w-10 h-10 rounded bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-yellow-500 hover:border-yellow-500 transition-all">
                <Instagram size={20} />
              </a>
              <a href="https://www.youtube.com/@CIN-PROD-ART" target="_blank" rel="noreferrer" className="w-10 h-10 rounded bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-yellow-500 hover:border-yellow-500 transition-all">
                <Youtube size={20} />
              </a>
            </div>
          </div>
        </div>

        {/* Form Side */}
        <div className="bg-zinc-900/30 border border-zinc-800 p-8 md:p-10 rounded-lg backdrop-blur-sm">
          {submitted ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center text-green-500">
                <Send size={40} />
              </div>
              <h3 className="text-2xl font-bold text-white">تم استلام رسالتك!</h3>
              <p className="text-zinc-400">شكراً لتواصلك معنا. سنقوم بالرد عليك في أقرب وقت ممكن.</p>
              <button 
                onClick={() => setSubmitted(false)}
                className="mt-6 text-yellow-500 hover:underline"
              >
                إرسال رسالة أخرى
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <h3 className="text-2xl font-bold text-white mb-6">أرسل لنا رسالة</h3>
              
              <div>
                <input
                  type="text"
                  id="name"
                  name="name"
                  required
                  value={formState.name}
                  onChange={handleChange}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded p-3 text-white focus:outline-none focus:border-yellow-500 transition-colors"
                  placeholder="الاسم"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formState.email}
                    onChange={handleChange}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded p-3 text-white focus:outline-none focus:border-yellow-500 transition-colors"
                    placeholder="البريد الإلكتروني"
                  />
                </div>
                <div>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    required
                    value={formState.phone}
                    onChange={handleChange}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded p-3 text-white focus:outline-none focus:border-yellow-500 transition-colors"
                    placeholder="الهاتف"
                  />
                </div>
              </div>

              <div>
                <select
                  id="service"
                  name="service"
                  required
                  value={formState.service}
                  onChange={handleChange}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded p-3 text-white focus:outline-none focus:border-yellow-500 transition-colors"
                >
                  <option value="">اختر نوع الخدمة</option>
                  <option value="video">تصوير فيديو كليب</option>
                  <option value="montage">مونتاج</option>
                  <option value="photography">تصوير فوتوغرافي</option>
                  <option value="production">إنتاج فني</option>
                </select>
              </div>

              <div>
                <textarea
                  id="message"
                  name="message"
                  rows={5}
                  required
                  value={formState.message}
                  onChange={handleChange}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded p-3 text-white focus:outline-none focus:border-yellow-500 transition-colors resize-none"
                  placeholder="رسالتك"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-yellow-600 hover:bg-yellow-500 text-black font-bold py-4 px-6 rounded transition-all flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'جاري الإرسال...' : 'إرسال'}
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default Contact;