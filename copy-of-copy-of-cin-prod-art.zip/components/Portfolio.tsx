import React, { useState } from 'react';
import { Project } from '../types';
import { PlayCircle, Camera } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Workaround for TypeScript errors where motion props are not recognized
const MotionDiv = motion.div as any;

const projects: Project[] = [
  {
    id: 1,
    title: "Bibi School",
    category: "فيديو كليب",
    youtubeId: "srq9cui757c",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 2,
    title: "lover 7080",
    category: "فيديو كليب",
    youtubeId: "AF5B8RDori8",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 3,
    title: "joujma",
    category: "فيديو كليب",
    youtubeId: "rZLOozESI40",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 4,
    title: "joujma 2",
    category: "فيديو كليب",
    youtubeId: "tjij9iZxuh8",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 5,
    title: "ouba",
    category: "فيديو كليب",
    youtubeId: "auVgws8It9s",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 6,
    title: "Tommy",
    category: "فيديو كليب",
    youtubeId: "mit7WUSS-KY",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 7,
    title: "sousman",
    category: "فيديو كليب",
    youtubeId: "NxDxtWXRxHc",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 8,
    title: "ACE",
    category: "فيديو كليب",
    youtubeId: "-8X3zyFzFjA",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 9,
    title: "kochmare ft b boj",
    category: "فيديو كليب",
    youtubeId: "-JkPCBxt6eU",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 10,
    title: "sami lmc",
    category: "فيديو كليب",
    youtubeId: "ZyOpnDxpdxs",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 11,
    title: "sami lmc 2",
    category: "فيديو كليب",
    youtubeId: "8lm9z5o-quk",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  },
  {
    id: 12,
    title: "Kamara",
    category: "فيديو كليب",
    youtubeId: "8uhpIVQHbnU",
    description: "كليب موسيقي من إنتاج Cin Prod Art."
  }
];

const categories = ["الكل", "فيديو كليب", "مونتاج", "فوتوغرافي", "إنتاج فني"];

const Portfolio: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState("الكل");
  const [playingVideos, setPlayingVideos] = useState<number[]>([]);

  const filteredProjects = activeFilter === "الكل" 
    ? projects 
    : projects.filter(p => p.category === activeFilter);

  const handlePlayVideo = (id: number) => {
    setPlayingVideos((prev) => [...prev, id]);
  };

  return (
    <section className="min-h-screen bg-zinc-950 pt-24 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">معرض <span className="text-yellow-500">الأعمال</span></h2>
          <div className="h-1 w-20 bg-yellow-600 mx-auto"></div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`relative px-6 py-2 rounded-full text-sm font-semibold transition-colors duration-300 z-10 ${
                activeFilter === cat
                  ? 'text-black'
                  : 'text-zinc-400 hover:text-yellow-500'
              }`}
            >
              {activeFilter === cat && (
                <MotionDiv
                  layoutId="activeFilter"
                  className="absolute inset-0 bg-yellow-500 rounded-full -z-10"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        <MotionDiv 
          layout 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode='popLayout'>
            {filteredProjects.map((project) => (
              <MotionDiv 
                layout
                key={project.id} 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
                className={`group relative overflow-hidden rounded-sm bg-zinc-900 border border-zinc-800 hover:border-yellow-500/50 transition-colors duration-500 ${project.youtubeId ? 'flex flex-col' : ''}`}
              >
                {project.youtubeId ? (
                  <>
                    {/* Video Card Design */}
                    <div className="w-full aspect-video bg-black relative">
                       {playingVideos.includes(project.id) ? (
                        <iframe 
                          width="100%" 
                          height="100%" 
                          src={`https://www.youtube.com/embed/${project.youtubeId}?autoplay=1`} 
                          title={project.title} 
                          frameBorder="0" 
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                          allowFullScreen
                          className="w-full h-full"
                        ></iframe>
                       ) : (
                        <div 
                          className="w-full h-full relative cursor-pointer"
                          onClick={() => handlePlayVideo(project.id)}
                        >
                           <img 
                            src={`https://img.youtube.com/vi/${project.youtubeId}/hqdefault.jpg`} 
                            alt={project.title} 
                            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all duration-500"
                           />
                           <div className="absolute inset-0 flex items-center justify-center">
                             <div className="w-16 h-16 rounded-full bg-yellow-500/80 flex items-center justify-center transform group-hover:scale-110 transition-transform duration-300 backdrop-blur-sm">
                               <PlayCircle className="w-10 h-10 text-black fill-current opacity-80" />
                             </div>
                           </div>
                        </div>
                       )}
                    </div>
                    <div className="p-5 text-right bg-zinc-900 border-t border-zinc-800 flex-1 flex flex-col justify-center">
                      <span className="text-yellow-500 text-xs font-bold uppercase tracking-widest mb-2 block">
                        {project.category}
                      </span>
                      <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                      <p className="text-zinc-400 text-sm">{project.description}</p>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Image Card Design */}
                    <div className="w-full aspect-[3/4] relative overflow-hidden group">
                      <img 
                        src={project.image} 
                        alt={project.title}
                        className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                      />
                       {/* Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                        <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 text-right">
                            <span className="text-yellow-500 text-xs font-bold uppercase tracking-widest mb-2 block">
                            {project.category}
                            </span>
                            <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                            <p className="text-zinc-400 text-sm line-clamp-2">{project.description}</p>
                            <div className="mt-4 flex items-center justify-end text-white cursor-pointer hover:text-yellow-500">
                            <span className="ml-2 text-sm font-semibold">عرض المشروع</span>
                            <Camera size={20} />
                            </div>
                        </div>
                        </div>
                    </div>
                  </>
                )}
              </MotionDiv>
            ))}
          </AnimatePresence>
        </MotionDiv>

        {filteredProjects.length === 0 && (
          <MotionDiv 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center text-zinc-500 py-20"
          >
            <p>لا توجد مشاريع في هذا القسم حالياً.</p>
          </MotionDiv>
        )}
      </div>
    </section>
  );
};

export default Portfolio;