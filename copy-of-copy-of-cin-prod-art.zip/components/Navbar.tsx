import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { PageView } from '../types';

interface NavbarProps {
  currentPage: PageView;
  setPage: (page: PageView) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, setPage }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { id: PageView.HOME, label: 'الرئيسية' },
    { id: PageView.PORTFOLIO, label: 'أعمالنا' },
    { id: PageView.SERVICES, label: 'خدماتنا' },
    { id: PageView.CONTACT, label: 'تواصل معنا' },
  ];

  const handleNavClick = (page: PageView) => {
    setPage(page);
    setIsOpen(false);
  };

  return (
    <nav className="fixed top-0 w-full z-50 bg-zinc-950/90 backdrop-blur-md border-b border-zinc-800 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-24">
          
          {/* Logo Section */}
          <div 
            className="flex items-center cursor-pointer group gap-4 relative" 
            onClick={() => handleNavClick(PageView.HOME)}
          >
            {/* Ambient Glow Effect */}
            <div className="absolute -inset-4 bg-yellow-500/10 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
            
            <img 
              src="C:\Users\SKYMIL\Pictures\images\CIN.png" 
              alt="CIN PROD Logo" 
              className="relative h-16 w-auto object-contain drop-shadow-lg group-hover:scale-105 transition-transform duration-300"
            />
            
            <div className="flex flex-col relative z-10 justify-center">
              <span className="text-3xl font-black tracking-tight text-white leading-none font-sans">
                CIN <span className="text-transparent bg-clip-text bg-gradient-to-br from-yellow-400 via-yellow-500 to-yellow-700">PROD</span>
              </span>
              <span className="text-[0.6rem] tracking-[0.35em] text-zinc-500 font-bold uppercase text-left pl-0.5 group-hover:text-yellow-500/80 transition-colors duration-300">
                ART PRODUCTION
              </span>
            </div>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-6 space-x-reverse">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative px-2 py-2 text-sm font-bold tracking-wide transition-colors duration-300 group/btn ${
                    currentPage === item.id
                      ? 'text-yellow-500'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {item.label}
                  {/* Hover/Active underline effect */}
                   <span className={`absolute bottom-0 left-0 w-full h-0.5 bg-yellow-500 transform transition-transform duration-300 origin-right ${
                     currentPage === item.id ? 'scale-x-100' : 'scale-x-0 group-hover/btn:scale-x-100'
                   }`}></span>
                </button>
              ))}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-zinc-400 hover:text-yellow-500 hover:bg-zinc-900 focus:outline-none transition-colors"
            >
              {isOpen ? <X className="h-8 w-8" /> : <Menu className="h-8 w-8" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      <div className={`md:hidden bg-zinc-950 border-b border-zinc-800 overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-64 opacity-100' : 'max-h-0 opacity-0'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`block w-full text-right px-4 py-3 border-r-2 transition-all duration-200 ${
                currentPage === item.id
                  ? 'border-yellow-500 text-yellow-500 bg-zinc-900/50'
                  : 'border-transparent text-zinc-300 hover:text-white hover:bg-zinc-900 hover:border-zinc-700'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};



export default Navbar;