import React from 'react';
import { Service } from '../types';
import { Clapperboard, Scissors, Camera, Music, Video } from 'lucide-react';

const services: Service[] = [
  {
    id: 1,
    title: "تصوير فيديو كليب",
    description: "معدات سينمائية متطورة، إخراج فني مبتكر، وإضاءة احترافية لإظهار رؤيتك الموسيقية بأفضل صورة.",
    icon: <Video className="w-12 h-12 text-yellow-500" />,
    image: "https://picsum.photos/800/600?grayscale&random=10"
  },
  {
    id: 2,
    title: "المونتاج والتلوين",
    description: "خدمات ما بعد الإنتاج، تصحيح ألوان (Color Grading) سينمائي، ومؤثرات بصرية ترفع من جودة العمل.",
    icon: <Scissors className="w-12 h-12 text-yellow-500" />,
    image: "https://picsum.photos/800/600?grayscale&random=11"
  },
  {
    id: 3,
    title: "تصوير فوتوغرافي",
    description: "جلسات تصوير احترافية للأزياء، المنتجات، والبورتريه بلمسة فنية وطابع Urban مميز.",
    icon: <Camera className="w-12 h-12 text-yellow-500" />,
    image: "https://picsum.photos/800/600?grayscale&random=12"
  },
  {
    id: 4,
    title: "الإنتاج الفني المتكامل",
    description: "إدارة المشروع من الفكرة إلى التنفيذ، توفير الطاقم، المواقع، والتراخيص اللازمة.",
    icon: <Clapperboard className="w-12 h-12 text-yellow-500" />,
    image: "https://picsum.photos/800/600?grayscale&random=13"
  }
];

const Services: React.FC = () => {
  return (
    <section className="min-h-screen bg-zinc-950 py-24 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-yellow-600/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-zinc-800/20 rounded-full blur-3xl translate-x-1/2 translate-y-1/2"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">خدمات <span className="text-yellow-500">Cin Prod Art</span></h2>
          <p className="text-zinc-400 max-w-2xl mx-auto">نقدم حلولاً إبداعية متكاملة تناسب جميع احتياجات الإنتاج الفني بجودة عالمية.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service) => (
            <div 
              key={service.id} 
              className="group bg-zinc-900/50 border border-zinc-800 hover:border-yellow-500/30 p-8 rounded-sm transition-all duration-300 hover:bg-zinc-900 hover:-translate-y-1 flex flex-col md:flex-row gap-6"
            >
              <div className="flex-shrink-0 flex items-start justify-center md:justify-start">
                <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-full group-hover:border-yellow-500/50 transition-colors">
                  {service.icon}
                </div>
              </div>
              <div className="text-center md:text-right flex-1">
                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-yellow-500 transition-colors">{service.title}</h3>
                <p className="text-zinc-400 leading-relaxed mb-6">{service.description}</p>
                <div className="h-48 w-full overflow-hidden rounded-sm grayscale group-hover:grayscale-0 transition-all duration-500">
                  <img src={service.image} alt={service.title} className="w-full h-full object-cover" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;