import React from 'react';
import { PageView } from '../types';
import { Play, ChevronDown } from 'lucide-react';

interface HeroProps {
  setPage: (page: PageView) => void;
}

const Hero: React.FC<HeroProps> = ({ setPage }) => {
  return (
    <div className="relative h-screen w-full overflow-hidden flex items-center justify-center">
      {/* Background Image acting as Video Placeholder */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://picsum.photos/1920/1080?grayscale&blur=2"
          alt="Cinematic Background"
          className="w-full h-full object-cover opacity-50 scale-110 animate-[pulse_10s_ease-in-out_infinite]"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/70 via-zinc-950/50 to-zinc-950" />
        {/* Mesh Grid Overlay for Urban Feel */}
        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <div className="mb-6 flex justify-center">
            <div className="h-1 w-24 bg-yellow-500 rounded-full"></div>
        </div>
        <h1 className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tight leading-tight">
          نحول رؤيتك إلى <br />
          <span className="text-gold">واقع سينمائي</span>
        </h1>
        <p className="text-lg md:text-2xl text-zinc-300 mb-10 max-w-2xl mx-auto leading-relaxed font-light">
          شركة Cin Prod Art للإنتاج الفني. ندمج الإبداع الفني مع الطابع الحضري الحديث لتقديم أعمال تخلد في الذاكرة.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => setPage(PageView.PORTFOLIO)}
            className="px-8 py-4 bg-yellow-600 hover:bg-yellow-500 text-black font-bold text-lg rounded-sm transition-all transform hover:scale-105 flex items-center"
          >
            <Play className="ml-2 h-5 w-5 fill-black" />
            شاهد أعمالنا
          </button>
          <button
            onClick={() => setPage(PageView.CONTACT)}
            className="px-8 py-4 border-2 border-zinc-500 hover:border-white text-white font-bold text-lg rounded-sm transition-all hover:bg-white hover:text-black"
          >
            تواصل معنا
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce text-zinc-500">
        <ChevronDown size={32} />
      </div>
    </div>
  );
};

export default Hero;