import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Portfolio from './components/Portfolio';
import Services from './components/Services';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { PageView } from './types';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<PageView>(PageView.HOME);

  const renderPage = () => {
    switch (currentPage) {
      case PageView.HOME:
        return <Hero setPage={setCurrentPage} />;
      case PageView.PORTFOLIO:
        return <Portfolio />;
      case PageView.SERVICES:
        return <Services />;
      case PageView.CONTACT:
        return <Contact />;
      default:
        return <Hero setPage={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white selection:bg-yellow-500 selection:text-black flex flex-col">
      <Navbar currentPage={currentPage} setPage={setCurrentPage} />
      <main className="flex-grow">
        {renderPage()}
      </main>
      {currentPage !== PageView.HOME && <Footer />}
    </div>
  );
};

export default App;